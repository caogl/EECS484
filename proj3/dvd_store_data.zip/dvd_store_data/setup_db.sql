\i pgsqlds2_delete_all.sql
\i pgsqlds2_create_tbl.sql

\i pgsqlds2_load_cust.sql
\i pgsqlds2_load_prod.sql 
\i pgsqlds2_load_orders.sql 
\i pgsqlds2_load_orderlines.sql 
\i pgsqlds2_load_cust_hist.sql 

\i pgsqlds2_load_inv.sql

set enable_bitmapscan=off; 
